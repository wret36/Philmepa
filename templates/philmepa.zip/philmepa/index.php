<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<jdoc:include type="head" />
		<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template;?>/css/style.css" type="text/css"/>
	</head>
	<body>
		<div id="main">
			<div id="header">
				<div id="top">
					<div id="header-top">
						<div id="logo">
							<img alt="logo" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template;?>images/logo_06.png" />
							<div class="logo-name">PHILMEPA</div>
							<div class="logo-slogan">Philippine Marine Environment Protection Association</div>
						</div>
						<div id="header-right">
							<div id="search">
								<input type="text" />
							</div>
						</div>
					</div>
				</div>
				<div id="bottom">
					<div id="header-bottom">
						<div id="menu">
							<jdoc:include type="modules" name="primary-menu" />
						</div>
						<div id="banner" >
							<img alt="logo" src="images/img2.jpg" />
						</div>
					</div>
				</div>
			</div>
			<div id="content">
				<div class="container">
					<div class="left">
						<div id="latest-news">
							<jdoc:include type="modules" name="latest-news" />
						</div>
						<div id="sponsor">
							<jdoc:include type="modules" name="sponsor" />
						</div>
					</div>
					<div class="right">
						<div id="main-content">
							<jdoc:include type="component" />
						</div>
					</div>
				</div>
			</div>
			<div id="footer">
				<div id="footer-content">
					<jdoc:include type="modules" name="footer_menu" />
				</div>
			</div>
		</div>
	</body>
</html>
